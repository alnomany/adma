<?php
namespace Braintree\MerchantAccount;

use Braintree\Instance;

class FundingDetails extends Instance
{
    protected $_attributes = [];
}
class_alias('Braintree\MerchantAccount\FundingDetails', 'Braintree_MerchantAccount_FundingDetails');
